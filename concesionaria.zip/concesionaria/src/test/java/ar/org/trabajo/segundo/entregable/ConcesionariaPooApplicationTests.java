package ar.org.trabajo.segundo.entregable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcesionariaPooApplicationTests {

	@Test
	void contextLoads() {
	}

}
