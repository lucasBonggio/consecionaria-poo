package ar.org.trabajo.segundo.entregable.logica;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.trabajo.segundo.entregable.entidades.Vehiculo;

public class Concesionaria {

    public void imprimirVehiculos(List<Vehiculo> vehiculos){
        vehiculos.forEach(System.out::println);
    }

    public void imprimirVehiculoMasCaro(List<Vehiculo> vehiculos){
        String vehiculoMasCaro = vehiculos
                                    .stream()
                                    .max(Comparator.comparing(Vehiculo::getPrecio))
                                    .get()
                                    .getDescription();

        System.out.println("Vehículo más caro: " + vehiculoMasCaro);
    }
    
    public void imprimirVehiculoMasBarato(List<Vehiculo> vehiculos){
        String vehiculoMasBarato = vehiculos
                                        .stream()
                                        .min(Comparator.comparing(Vehiculo::getPrecio))
                                        .get()
                                        .getDescription();

        System.out.println("Vehículo más barato: " + vehiculoMasBarato);
    }

    public void imprimirVehiculoConY(List<Vehiculo> vehiculos){
        System.out.print("Vehículo que contiene en el modelo la letra `Y`: ");
        vehiculos
            .stream()
            .filter(v -> v.getModelo().toLowerCase().contains("y"))
            .forEach(v -> System.out.print(v.getDescription() + " " + v.precioFormateado()));
    }

    public void imprimirVehiculosOrdenadosPorPrecioDescendente(List<Vehiculo> vehiculos){
        System.out.println("Vehículos ordenados por precio de mayor a menor: ");
        vehiculos
            .stream()
            .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
            .forEach(v -> System.out.println(v.getDescription()));
    }

    public void imprimirVehiculosPorOrdenNatural(List<Vehiculo> vehiculos){
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio): ");
        vehiculos
            .stream()
            .sorted(Comparator.comparing(Vehiculo::getMarca)
            .thenComparing(Vehiculo::getModelo)
            .thenComparing(Vehiculo::getPrecio))
            .forEach(System.out::println);
    }

    public List<Vehiculo> cargarVehiculos(Vehiculo...vehiculo){
        List<Vehiculo> vehiculosCargados = new ArrayList<>();

        for(Vehiculo v: vehiculo){
            vehiculosCargados.add(v);
        }
        return vehiculosCargados;
    }
}