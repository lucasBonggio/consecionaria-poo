package ar.org.trabajo.segundo.entregable.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Concesionaria {

    List<Vehiculo> vehiculos = new ArrayList<>();
    

    public void mostrarDatos() {
        vehiculos.forEach(System.out::println);

        System.out.println("==================================");

        String vehiculoMasCaro = vehiculos
            .stream()
            .max(Comparator.comparing(Vehiculo::getPrecio))
            .get()
            .getDescription();

        System.out.println("Vehículo más caro: " + vehiculoMasCaro);

        String vehiculoMasBarato = vehiculos
            .stream()
            .max(Comparator.comparing(Vehiculo::getPrecio).reversed())
            .get()
            .getDescription();

        System.out.println("Vehículo más barato: " + vehiculoMasBarato);

        System.out.print("Vehículo que contiene en el modelo la letra `Y`: ");
        vehiculos
            .stream()
            .filter(v -> v.getModelo().contains("Y"))
            .forEach(v -> System.out.print(v.getDescription() + " " + v.precioFormateado()));

        System.out.println("\n==================================");

        System.out.println("Vehículos ordenados por precio de mayor a menor: ");
        vehiculos
            .stream()
            .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
            .forEach(v -> System.out.println(v.getDescription()));

        System.out.println("==================================");

        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio): ");
        vehiculos
            .stream()
            .sorted(Comparator.comparing(Vehiculo::getMarca))
            .forEach(System.out::println);
    }

    public void cargarVehiculos(){
        vehiculos.add(new Auto("Peugeot", "206", 200000, 4));    
        vehiculos.add(new Moto("Honda", "Titan",60000, 125));
        vehiculos.add(new Auto("Peugeot", "208", 250000, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50, 160));    
    }

}