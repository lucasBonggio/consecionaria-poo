package ar.org.trabajo.segundo.entregable.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Moto extends Vehiculo {
    
    private int cilindradas;

    public Moto(String marca, String modelo, double precio, int cilindradas) {
        super(marca, modelo, precio);
        this.cilindradas = cilindradas;
    }


    public String precioFormateado(double precio){
        return String.format("$%,.2f", precio);
    }
    
    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %dc // Precio: %s", this.getMarca(), this.getModelo(), cilindradas, precioFormateado(this.getPrecio()));
    }

    @Override
    public String getDescription() {
        return this.getMarca() + " " + this.getModelo();
    }

}
