package ar.org.trabajo.segundo.entregable.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {

    private String marca;
    private String modelo;
    private double precio;


    @Override
    public abstract String toString();

    public abstract String getDescription();

    @Override
    public int compareTo(Vehiculo otroVehiculo){
        String thisVehiculo = this.marca + ", " + this.getModelo() + ", " + this.getPrecio();
        String segundoVehiculo = otroVehiculo.getMarca() + ", " + otroVehiculo.getModelo() + ", " + otroVehiculo.getPrecio();
        return thisVehiculo.compareTo(segundoVehiculo);
    }

    public String precioFormateado(){
        return String.format("$%,.2f", this.precio);
    }
}
