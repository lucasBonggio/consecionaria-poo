package ar.org.trabajo.segundo.entregable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ar.org.trabajo.segundo.entregable.entidades.Concesionaria;

@SpringBootApplication
public class ConcesionariaPooApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcesionariaPooApplication.class, args);
		
		Concesionaria concesionaria = new Concesionaria();
		concesionaria.cargarVehiculos();
		concesionaria.mostrarDatos();
	}

}
