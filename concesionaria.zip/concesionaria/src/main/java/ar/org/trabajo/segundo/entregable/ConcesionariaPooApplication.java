package ar.org.trabajo.segundo.entregable;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ar.org.trabajo.segundo.entregable.entidades.Auto;
import ar.org.trabajo.segundo.entregable.entidades.Concesionaria;
import ar.org.trabajo.segundo.entregable.entidades.Moto;
import ar.org.trabajo.segundo.entregable.entidades.Vehiculo;

@SpringBootApplication
public class ConcesionariaPooApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcesionariaPooApplication.class, args);
		Concesionaria concesionaria = new Concesionaria();
		
		Auto auto = new Auto("Peugeot", "206", 200000, 4);
        Moto moto = new Moto("Honda", "Titan", 60000, 125);
        Auto auto1 = new Auto("Peugeot", "208", 250000, 5);
		Moto moto1 = new Moto("Yamaha", "YBR", 80500.5, 160);

		List<Vehiculo> vehiculos = concesionaria.cargarVehiculos(auto, moto, auto1, moto1);

		concesionaria.imprimirVehiculos(vehiculos);
		
		System.out.println("=============================");
		concesionaria.imprimirVehiculoMasCaro(vehiculos);
		concesionaria.imprimirVehiculoMasBarato(vehiculos);
		concesionaria.imprimirVehiculoConY(vehiculos);
		
		System.out.println("\n=============================");
		concesionaria.imprimirVehiculosOrdenadosPorPrecioDescendente(vehiculos);

		System.out.println("=============================");
		concesionaria.imprimirVehiculosPorOrdenNatural(vehiculos);
	}

}
