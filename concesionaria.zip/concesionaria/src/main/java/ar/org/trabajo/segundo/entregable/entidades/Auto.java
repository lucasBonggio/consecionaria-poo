package ar.org.trabajo.segundo.entregable.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Auto extends Vehiculo {

    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: %s", this.getMarca(), this.getModelo(), puertas, this.precioFormateado());
    }

    @Override
    public String getDescription() {
        return this.getMarca() + " " + this.getModelo();
    }
}
